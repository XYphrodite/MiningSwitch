# Mining Switch 4

Дашборд для ПК с майнингом: большая кнопка вкл/выкл XMRig (CPU) и GPU-майнера (SRBMiner / lolMiner), значок возле часов, примерная оценка дохода своего ПК и всей сети, плитки ресурсов. Приложение управляет майнерами через локальный [mining-fleet-agent](https://github.com/XYphrodite/mining-fleet) и не меняет кошельки и настройки выплат.

**Платформа**: Windows 10/11, .NET 10 (WPF) · нужен установленный `mining-fleet-agent` и .NET 10 Desktop Runtime.

## Установка и запуск

```powershell
powershell -c "irm https://raw.githubusercontent.com/XYphrodite/MiningSwitch/main/install.ps1 | iex"
```

Установка кладёт файлы в `C:\Program Files\MiningSwitch`, создаёт ярлык на рабочем столе и в автозагрузке пользователя. Запуск — `MiningSwitch.exe`; окно консоли не появляется. Для запуска сразу возле часов: `MiningSwitch.exe -Tray`. Крестик сворачивает окно к часам; «Закрыть приложение» в меню значка завершает его. Повторный запуск открывает уже работающее окно.

## Что показывает

- Состояние XMRig (CPU) и GPU-майнера (`SRBMiner` для Pearl / `lolMiner` для Tari) и их скорость с автошкалированием SI (`TH/s`, `GH/s`, `g/s`).
- Кнопка вкл/выкл: останавливает и запускает оба майнера и переключает их автовозобновление. Ручное выключение сохраняется после перезагрузки; команды внешней консоли управления сетью могут изменить эту политику.
- Плитки: загрузка процессора, занятая память, свободное место на C: и D:.
- Примерная доходность в рублях за сутки: отдельно для этого ПК (CPU + GPU) и для всех воркеров общих кошельков HashVault и Kryptex / LuckyPool, включая этот ПК.

## Доходность — это оценка

Верхняя сумма — прогноз CPU + GPU только этого ПК по средней скорости его воркера за 24 часа. Нижняя — такой же прогноз по всем воркерам двух общих кошельков сети. Суммы **не включают** электричество, PPLNS и удачу пула и не равны фактическим начислениям.

- CPU: Monero/HashVault; оценка — средний хешрейт воркера за сутки × 86400 × награда блока / сложность сети, за вычетом комиссии пула.
- GPU: Pearl (`pearlhash` / `SRBMiner` / Kryptex `prl.kryptex.network`, оценка по `avg_hashrate_24h` воркера и `estimated_profit_day` за вычетом PPS+ комиссии пула, курс PRL/RUB — CoinGecko `pearl-2`) или Tari C29 (`lolMiner` / LuckyPool, оценка по `profit24hPer1Ghs`, курс XTM/RUB — CoinGecko).
- Котировки старше двух часов не принимаются. При недоступности одного источника общая сумма не показывается как полный доход — видна доступная часть с пояснением.

## Подключение

Настройки агента читаются из `%ProgramFiles%\mining-fleet-agent\appsettings.json`; его API вызывается только через loopback, токен используется в памяти и не передаётся пулу. Имя своего воркера приложение берёт из агента. Публичные API HashVault, Kryptex, LuckyPool и CoinGecko запрашиваются напрямую, без токена. Отключённый агент отображается как «Нет связи с агентом».

## Разработка

Исходники: `src/MiningSwitch.App` (C# 14, .NET 10, WPF); DTO и клиент агента адаптированы из [mining-fleet](https://github.com/XYphrodite/mining-fleet).

```powershell
# Сборка
dotnet build src/MiningSwitch.App -c Release

# Тесты (математика оценок)
dotnet test tests/MiningSwitch.Tests -c Release

# Релиз (один exe)
dotnet publish src/MiningSwitch.App -c Release -r win-x64 --self-contained false -p:PublishSingleFile=true -o publish

# Проверка без окна: агент, пулы, ресурсы -> JSON-отчёт
.\publish\MiningSwitch.exe --selftest report.json
```

Документация пула: https://hashvault.pro/monero/api
